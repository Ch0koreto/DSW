    <footer>
        <hr>
        <small>[Junjie] [Chen] | Examen Tema 3</small>
    </footer>
</body>
</html>